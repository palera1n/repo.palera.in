//
//  FLEXCodeFontCell.h
//  FLEX
//
//  Created by Tanner on 12/27/19.
//  Copyright © 2020 FLEX Team. All rights reserved.
//

#import "FLEXMultilineTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface FLEXCodeFontCell : FLEXMultilineDetailTableViewCell

@end

NS_ASSUME_NONNULL_END
