//
//  FLEXArgumentInputNotSupportedView.h
//  Flipboard
//
//  Created by Ryan Olson on 6/18/14.
//  Copyright (c) 2020 FLEX Team. All rights reserved.
//

#import "FLEXArgumentInputTextView.h"

@interface FLEXArgumentInputNotSupportedView : FLEXArgumentInputTextView

@end
